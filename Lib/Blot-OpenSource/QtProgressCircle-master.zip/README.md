# QtProgressCircle
ProgressCircle is circular progress bar widget for Qt

![alt tag](https://raw.githubusercontent.com/mofr/QtProgressCircle/master/Demo.png)
